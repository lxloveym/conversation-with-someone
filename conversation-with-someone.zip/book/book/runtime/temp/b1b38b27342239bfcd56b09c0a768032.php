<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"D:\phpstudy_pro\WWW\priactise\public/../application/admin\view\login\index.html";i:1650713009;}*/ ?>
<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>login</title>
    <link rel="shortcut icon" href="/images/favicon-2021082605202820.ico">
    <link rel="stylesheet" type="text/css" href="/static/login/css/normalize.css" />
    <link rel="stylesheet" type="text/css" href="/static/login/css/demo.css" />
    <!--必要样式-->
    <link rel="stylesheet" type="text/css" href="/static/login/css/component.css" />
    <!--[if IE]>
<script src="/static/login/js/html5.js"></script>
<![endif]-->
</head>

<body>
    <div class="container demo-1">
        <div class="content">
            <div id="large-header" class="large-header">
                <canvas id="demo-canvas"></canvas>
                <div class="logo_box">
                    <h3>“心灵的窗口”图书管理系统</h3>
                    <form action="<?php echo url('login/check'); ?>" name="f" method="post">
                        <div class="input_outer">
                            <span class="u_user"></span>
                            <input name="username" class="text" style="color: #FFFFFF !important" type="text" placeholder="请输入账户" required>
                        </div>
                        <div class="input_outer">
                            <span class="us_uer"></span>
                            <input name="password" class="text" style="color: #FFFFFF !important; position:absolute; z-index:100;" value="" type="password" placeholder="请输入密码" required>
                        </div>

                        <div class="input_outer">
                            <span class="us_uer"></span>
                            <input name="code" class="text" style="color: #FFFFFF !important; position:absolute; z-index:100;" value="" type="text" placeholder="请输入验证码" required>
                        </div>
                        <div class="input_outer">
                            <img width="100%" height="100%" src="<?php echo captcha_src(); ?>">
                        </div>
                        <div class="mb2">

                            <input class="act-but submit" style="color: #FFFFFF;width:100%;border:0" type="submit" value="登录">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /container -->
    <script src="/static/login/js/TweenLite.min.js"></script>
    <script src="/static/login/js/EasePack.min.js"></script>
    <script src="/static/login/js/rAF.js"></script>
    <script src="/static/login/js/demo-1.js"></script>
</body>

</html>