<?php

namespace app\admin\model;

use think\Model;

class Book extends Model
{

}