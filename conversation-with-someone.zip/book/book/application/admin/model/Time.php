<?php

namespace app\index\model;

use think\Model;

class Time extends Model
{

}