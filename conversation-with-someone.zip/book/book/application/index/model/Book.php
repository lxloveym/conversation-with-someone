<?php

namespace app\index\model;

use think\Model;

class Book extends Model
{

}