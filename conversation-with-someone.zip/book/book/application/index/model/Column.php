<?php

namespace app\index\model;

use think\Model;

class Column extends Model
{

}